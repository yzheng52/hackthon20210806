

// the hello world program
var value = 0;
function countup()
{
	var element = document.getElementById("origin");
	++value;
	
	console.log(value);
	document.getElementById("origin").innerHTML = value;
}

function countdown()
{
	var element = document.getElementById("copy");
	--value;
	
	console.log(value);
	document.getElementById("copy").innerHTML = value;
}