
function addcontentFirst1()
{
	localStorage.first = "1";
}

function addcontentFirst0()
{
	localStorage.first = "0";
}

function addcontentSecond1()
{
	localStorage.second = "1";
}

function addcontentSecond0()
{
	localStorage.second = "0";
}

function addcontentThird1()
{
	localStorage.third = "1";
}

function addcontentThird0()
{
	localStorage.third = "0";
}

function addcontentFourth1()
{
	localStorage.fourth = "1";
}

function addcontentFourth0()
{
	localStorage.fourth = "0";
}

function setcontent()
{
	content1();
	content2();
	content3();
	content4();
	content5();
}

function content1()
{
	var x = Number(localStorage.first);
	if(x==1)
	{
		document.getElementById("key2").src = "5-3.png";
	}
	else
	{
		document.getElementById("key2").src = "5-4.png";
	}
}

function content2()
{
	var x = Number(localStorage.second);
	if(x==1)
	{
		document.getElementById("key3").src = "6-3.png";
	}
	else
	{
		document.getElementById("key3").src = "6-4.png";
	}
}

function content3()
{
	var x = Number(localStorage.third);
	if(x==1)
	{
		document.getElementById("key4").src = "7-3.png";
	}
	else
	{
		document.getElementById("key4").src = "7-4.png";
	}
}

function content4()
{
	var x = Number(localStorage.fourth);
	if(x==1)
	{
		document.getElementById("key5").src = "8-3.png";
	}
	else
	{
		document.getElementById("key5").src = "8-4.png";
	}
}

function content5()
{
	document.getElementById("key6").src = "9-3.png";
}

function ending()
{
	var x = Number(localStorage.first) + Number(localStorage.second) + Number(localStorage.third) + Number(localStorage.fourth);
	console.log(x);
	if (x > 0)
	{
		document.getElementById("button1").href = "page11.html";
	}
	else
	{
		document.getElementById("button1").href = "page11-2.html";
	}
}