/**
 * 
 */
var img;
var count = 0;
var sum = 0;
var collectable = 0;

function changeclick()
{
	count = count + 1;
	if (count % 2 == 0)
	{
		document.getElementById("img1").src = "8-1.png";
		collectable = 0;
	}
	else
	{
		document.getElementById("img1").src = "8-2.png";
		collectable = 1;
	}
}

function setOldImage()
{
	document.getElementById("img1").src = "8-1.png";
}

function setNewImage()
{
	document.getElementById("img1").src = "8-2.png";
}

function click1()
{
	if(collectable == 1)
	{
		document.getElementById("keyword3").src = "8-5.png";
	}
}

function click3()
{
	if(collectable == 1)
	{
		document.getElementById("keyword3").src = "8-3.png";
	}
}

function click2()
{
	if(collectable == 1)
	{
		document.getElementById("keyword4").src = "8-6.png";
	}
}

function click4()
{
	if(collectable == 1)
	{
		document.getElementById("keyword4").src = "8-4.png";
	}
}