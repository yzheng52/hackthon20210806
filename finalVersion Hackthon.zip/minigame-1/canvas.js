var img;
var count = 0;
var sum = 0;
var collectable = 0;

function changeclick()
{
	count = count + 1;
	if (count % 2 == 0)
	{
		document.getElementById("img1").src = "news.png";
		collectable = 0;
	}
	else
	{
		document.getElementById("img1").src = "newsAndNote.png";
		collectable = 1;
	}
}

function setOldImage()
{
	document.getElementById("img1").src = "news.png";
}

function setNewImage()
{
	document.getElementById("img1").src = "newsAndNote.png";
}

function click1()
{
	if(collectable == 1)
	{
		document.getElementById("keyword3").src = "keyword1.png";
	}
}

function click3()
{
	if(collectable == 1)
	{
		document.getElementById("keyword3").src = "keyword3.png";
	}
}

function click2()
{
	if(collectable == 1)
	{
		document.getElementById("keyword4").src = "keyword2.png";
	}
}

function click4()
{
	if(collectable == 1)
	{
		document.getElementById("keyword4").src = "keyword4.png";
	}
}

