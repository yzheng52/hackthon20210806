var img;
var count = 0;
var sum = 0;
var collectable = 0;

function changeclick()
{
	count = count + 1;
	if (count % 2 == 0)
	{
		document.getElementById("img1").src = "9-1.png";
		collectable = 0;
	}
	else
	{
		document.getElementById("img1").src = "9-2.png";
		collectable = 1;
	}
}
/*
function setOldImage()
{
	document.getElementById("img1").src = "9-1.png";
}

function setNewImage()
{
	document.getElementById("img1").src = "9-2.png";
}
**/
function click1()
{
	if(collectable == 1)
	{
		document.getElementById("keyword3").src = "9-4.png";
	}
}

function click3()
{
	if(collectable == 1)
	{
		document.getElementById("keyword3").src = "9-3.png";
	}
}
/**
 * 
 */